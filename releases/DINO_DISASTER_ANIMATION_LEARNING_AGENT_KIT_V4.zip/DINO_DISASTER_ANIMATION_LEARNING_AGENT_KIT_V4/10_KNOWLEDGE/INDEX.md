# Searchable learning index — start here

**Use the search script, not memory alone:** `python 08_TOOLS/search_knowledge.py "impact reads" --expand`.

## Quick lookup

- Portal not emerged / masking / threshold → `LRN-0001`, `LRN-0007`, `CASE-0001`.
- Bad foot contact / pose reaction / shake → `LRN-0002` and `11_AFTER_EFFECTS/02_KEYFRAMES_GRAPH_EDITOR_AND_RIGS.md`.
- After Effects expression meaning / code usage → `LRN-0003`, `11_AFTER_EFFECTS/03_EXPRESSIONS_PLAIN_ENGLISH_DICTIONARY.md`, `04_EXPRESSION_COOKBOOK.md`.
- Camera, sound and motion context → `LRN-0004`, `11_AFTER_EFFECTS/06_CONTEXT_DRIVEN_TECHNIQUE_SELECTOR.md`, `01_RESEARCH/05_CONTEXT_COUPLING.md`.
- Solids/shape/track mattes/precomps → `LRN-0007`, `11_AFTER_EFFECTS/01_LAYERS_SOLIDS_MATTES_AND_PRECOMPS.md`.
- Impact accent flash/FX must follow actual contact → `LRN-0005`.
- Motion arc vs speed ramp vs camera trajectory → `LRN-0006`.
- Natural-language “bullet impact” full example → `LRN-0009`, `10_KNOWLEDGE/EXAMPLES/INT-0001_CINEMATIC_IMPACT_TRANSLATION.md`.
- What is learned vs tested? → `LRN-0008`, `LEARNING_LOG.md`, `09_HANDOFF/STATUS.md`.
- Open goals and conflicts → `00_START_HERE/06_EVOLVING_GOALS_AND_DIRECTIONS.md`, `07_CONFLICT_AND_INTERPRETATION_LOG.md`.

## How to grow this index

Add each stable ID, synonyms and relative file path on the same day as new research/render. Do not claim a lesson is fixed if it is only proposed. Search script scans all MD live, so index is a human shortcut rather than a stale search database.
