# Source ledger and evidence boundaries

**Checked:** 2026-11-19. This ledger lists publicly inspectable source links reviewed for this kit and their *supported* ideas. These sources describe professional practice or advice; they are not universal filmmaking laws. Specific timings, camera designs and mix choices in the dinosaur story are **our authored project decisions**, not quotes from these sources. Recheck URLs and recommendations when using the kit in the future.

## Directly inspected sources and what they actually support

| ID | Source and link | Supported principle | Role |
|---|---|---|---|
| S01 | [Walt Disney Animation: Story](https://www.disneyanimation.com/process/story/) | Story artists consider character, emotion, timing, staging and framing together, iterating from thumbnails | Story/layout workflow |
| S02 | [Walt Disney Animation: Layout & Final Layout](https://www.disneyanimation.com/process/layout/) | Shot staging, camera/lens choices, character blocking, composition, cutting, and emotional purpose interact | Camera/context |
| S03 | [Walt Disney Animation: Animation](https://www.disneyanimation.com/process/animation/) | Timing, staging, squash/stretch, anticipation, follow-through and secondary action | Motion craft |
| S04 | [Walt Disney Animation: Editorial & Sound](https://disneyanimation.com/process/editorial--sound/) | Editors shape rhythm/pacing with temp audio and music from early production | Editorial/sound integration |
| S05 | [Walt Disney Animation: Post Production](https://disneyanimation.com/process/post-production/) | Animation sound is constructed; Foley, designed effects and mixing support clarity and emotion | Audio creation |
| S06 | [Pixar: Toy Story 2, Colorscripts](https://www.pixar.com/toy-story-2) | Color scripts map film's narrative/emotional progression | Color dramaturgy |
| S07 | [Adobe: Continuity Editing](https://www.adobe.com/creativecloud/video/hub/ideas/what-is-continuity-editing-in-film.html) | Eyeline, action match, screen axis, eye-trace, editing continuity | Editing continuity |
| S08 | [Adobe: Shot sizes/angles](https://www.adobe.com/creativecloud/video/production/cinematography/camera-shots-and-angles.html) | Choice of shot size, viewpoint and camera movement changes emotional communication | Camera grammar |
| S09 | [Adobe: 180-degree rule](https://www.adobe.com/uk/creativecloud/video/discover/what-is-the-180-degree-rule.html) | Keeping camera on consistent side helps visual geography | Axis convention |
| S10 | [Adobe: Match cuts](https://www.adobe.com/uk/creativecloud/video/discover/match-cut.html) | Graphic, action, audio matches and sound bridges aid transitions | Editing bridges |
| S11 | [Frame.io: Post-Production Workflow](https://workflow.frame.io/guide/) | Editorial and post sound workflows; organized tracks, rough mix, Foley/backgrounds/emotional effects, final mixing, mono/stereo considerations | Sound workflow |
| S12 | [Film Independent: Subjective Sound Design](https://www.filmindependent.org/blog/guest-post-using-subjective-sound-design-to-create-emotion-and-interiority/) | Sonic perspective is selected according to character emotion and viewpoint, not only literal realism | Contextual sound |
| S13 | [BBC Academy: Using Sound in Your Radio Package](https://downloads.bbc.co.uk/academy/academyfiles/RadioPackages/Using%20sound%20in%20your%20radio%20package.pdf) | Atmosphere, close sounds, sonic shorthand, punctuation and bridges (PDF text accessible; screenshot access failed in research session) | Auxiliary auditory storytelling, limited verification |
| S14 | [YouTube Help: Recommended Upload Encoding](https://support.google.com/youtube/answer/1722171?hl=en) | MP4, H.264 SDR encoding, 48 kHz sample rate and accepted audio codecs; preserve source frame rate | Delivery recommendations |
| S15 | [EBU R128](https://tech.ebu.ch/publications/r128) and [Streaming Supplement R128S2](https://tech.ebu.ch/publications/r128s2) | EBU broadcast R128 uses -23 LUFS; web streaming may use other targets | Prevent inappropriate loudness claims |
| S16 | [Moovs Digital: How to Make an Animation Come to Life](https://www.moovsdigital.com/blog/how-to-make-an-animation-come-to-life) | Smooth motion, weight, spring, bounce and impact are tools to create life | Accessible motion technique |
| S17 | [80 Level: Senior Animator Shares a Trick](https://80.lv/articles/senior-animator-shares-a-trick-to-make-your-animations-feel-more-alive) | Gogan's whole-body response example: a jump should affect multiple body parts | Coherent acting |
| S18 | [Creativepool: The Art of Motion](https://creativepool.com/magazine/inspiration/the-art-of-motion-the-principles-of-animation-and-what-makes-it-great.33968) | Animation as storytelling; preproduction, production, post, distribution and animation principles | Production framing |
| S19 | [Frame.io: Silence over Sound](https://blog.frame.io/2016/10/21/silence-over-sound/) | Designed quiet/silence is an intentional expressive device | Quiet and contrast |

## Research synthesis, not literal claims from sources

- `R01`: **Context triple** — for every story beat define camera's narrative question, actor's intention/force, and sound's source/POV/priority; test whether all three communicate the *same* event without redundancy.
- `R02`: **Action contract** — major verb must be visually completed with contact or threshold proof, not merely implied by narration or effect.
- `R03`: **Three listening perspectives** — objective environment, character subjective hearing, audience editorial anticipation; label which is used and when changed.
- `R04`: **Camera cost rule** — a moving camera adds parallax/scale/change of focus, so it must earn that perceptual cost by revealing, following, contrasting or reframing.
- `R05`: **Single dominant idea per beat** — do not maximize movement, captions, score and camera energy at once; direct attention with deliberate hierarchy.
- `R06`: **Event-sourced cue sheet** — derive footsteps, impacts, contacts and their sound from frame-level events; allow intentional prelaps/offscreen cues with documented exceptions.
- `R07`: **No-media-no-verification** — a source file, proposed prompt or successful encoding check does not prove the performance was good. Inspect rendered evidence.

These are original production heuristics synthesized for this project, not imposed studio rules.

## Method limits

This research is a targeted synthesis of credible production workflows plus the user's three articles; it is **not** a systematic review of every cinema school or TV broadcaster's standards. Terms such as 30-degree rule, rule of thirds, three-point lighting, and classic 180-degree blocking are useful conventions with legitimate exceptions. Web metadata can change; a future agent should verify technical specifications against the target distribution platform instead of treating 2026 links as permanent.

## Additional cross-checks — context-dependent direction (2026-11-19)

These supplemental references reinforce the need to connect camera, performance, editing and sound to **specific viewer knowledge and emotion**. They do not prescribe the project's invented timing or stylization.

| ID | Source | Supported idea | Application |
|---|---|---|---|
| S20 | [The Science Behind Pixar — Sets and Cameras](https://sciencebehindpixar.org/pipeline/sets-and-cameras) | Camera placement, lens and composition guide where audiences look and how they feel; staging precedes finished animation. | The portal benchmark has a stable camera that reveals actual threshold crossing. |
| S21 | [Pixar in a Box — The Art of Storytelling](https://www.khanacademy.org/computing/pixar/storytelling) | Film grammar combines shot design, composition, movement and editing for story. | Every shot card contains a viewer question and intentional visual language. |
| S22 | [Walter Murch — Worldizing Film Sound](https://webofstories.com/play/walter.murch/50) | A sound can acquire the acoustic character of the environment depicted on screen. | Distinguish forest-open and apartment-interior sounds, and perspective shifts across portal. |
| S23 | [Walter Murch on sound layering and perception — Transom](https://transom.org/2005/walter-murch/) | Sound choices affect emotion, focus, and attention; competing layers can reduce clarity. | During the egg crack, retreat score/ambience emphasis so small sound remains readable. |
| S24 | [Film editing: constructing time and space — Reframing Cinema](https://pressbooks.pub/reframingcinema/chapter/editing/) | Continuity and bridging cuts organize perceived time/space; sound bridges can help carry emotional/spatial connection. | Separate time/space bridges from contact-locked Foley; preserve geography after scene cuts. |
| S25 | [Disney Animation — Story](https://www.disneyanimation.com/process/story/) | Storyboarding includes the character's emotional state, staging, timing and framing. | The action contract must exist before choosing a camera move. |

**Verification discipline:** The Disney/Pixar page descriptions and Murch interview extracts were checked against the public results in the current research. The distinctive `Contextual Directing Algorithm`, attention budget, and seven-link causal tests are **original project synthesis**, not industry standards verbatim.
