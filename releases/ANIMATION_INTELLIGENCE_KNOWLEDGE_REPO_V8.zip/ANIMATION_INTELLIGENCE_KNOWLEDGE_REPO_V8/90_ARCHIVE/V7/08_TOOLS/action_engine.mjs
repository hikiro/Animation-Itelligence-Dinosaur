/** Lesson 05 pure frame sampler. The result is control data, NOT a solved rig or a rendered frame.
 * Uses no mutable state, timers, browser APIs or random values. All endpoints are inclusive.
 * Caller must supply the parsed JSON array (can load via fs in Node or bundle in Remotion).
 */
const clamp=(x,min,max)=>Math.min(max,Math.max(min,x));
export const smoothstep=(t)=>{const x=clamp(t,0,1);return x*x*(3-2*x);};
export function sampleCurve(keyframes, frame) {
  if (!Array.isArray(keyframes)||keyframes.length<2) throw new Error('Need >=2 keyframes');
  if (!Number.isFinite(frame)) throw new Error('frame must be finite');
  if(frame <= keyframes[0][0]) return keyframes[0][1];
  if(frame >= keyframes.at(-1)[0]) return keyframes.at(-1)[1];
  for(let i=1;i<keyframes.length;i++) {
    const [endF,endV]=keyframes[i];const [startF,startV]=keyframes[i-1];
    if(endF<=startF) throw new Error('Keyframes must ascend');
    if(frame<=endF) return startV+(endV-startV)*smoothstep((frame-startF)/(endF-startF));
  }
  throw new Error('Unreachable interpolation state');
}
export function sampleAction(id, frame, recipes){
  if(!Array.isArray(recipes)) throw new Error('recipes is a parsed JSON array');
  const spec=recipes.find(x=>x.id===id);
  if(!spec) throw new Error(`Unknown recipe ${id}`);
  if(frame < 0 || frame >= spec.duration_frames) throw new RangeError(`Out of range: ${frame} / ${spec.duration_frames}`);
  const stages=['stimulus','perception','decision','anticipation','action','consequence'];
  const phase=stages.findLast(x=>frame>=spec.phase_frames[x]);
  const channels=Object.fromEntries(Object.entries(spec.curves).map(([key,curve])=>[key,sampleCurve(curve,frame)]));
  const p=spec.phase_frames;
  const events=Object.fromEntries(Object.entries(p).filter(([k])=>k!=='end').map(([k,start])=>[k,frame>=start]));
  return {id,frame,phase,channels,events,source_ids:spec.source_ids,kind:spec.category};
}
