# Emergency 60-second recovery card

**STOP producing.** Read `AGENTS.md`, `00_START_HERE/04_TRUTH_AND_RECOVERY.md`, `09_HANDOFF/STATUS.md`.

1. What is the most recent VERIFIED output, with exact path?
2. What stage is approved? Which stages were only proposed?
3. What is the first broken invariant (story/crossing/contact/camera/audio/technical)?
4. Which previous good component can be reused?
5. What is the smallest diagnostic render/test to isolate the root cause?
6. What evidence will prove the repair, including neighboring-state regression?
7. What status and defect files must be updated?

**Do not use “I think it passed previously” as evidence.** If the files are missing, set `UNVERIFIED` and ask for/retrieve actual assets rather than hallucinating a result. Never take a shortcut of fading through the portal instead of geometry/occlusion.
