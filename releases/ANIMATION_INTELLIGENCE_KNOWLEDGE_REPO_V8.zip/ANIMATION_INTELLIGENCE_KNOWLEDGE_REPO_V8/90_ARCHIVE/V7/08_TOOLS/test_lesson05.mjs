import {readFileSync} from 'node:fs';
import assert from 'node:assert/strict';
import {sampleAction,sampleCurve} from './action_engine.mjs';
const recipes=JSON.parse(readFileSync(new URL('../12_ACTION_INTELLIGENCE/DATA/action_recipes.json',import.meta.url),'utf8'));
let checks=0;
assert.equal(recipes.length,42);checks++;
assert.equal(new Set(recipes.map(r=>r.id)).size,42);checks++;
assert.equal(new Set(recipes.map(r=>r.slug)).size,42);checks++;
for(const r of recipes){
  assert.ok(r.utterance.length>12);checks++;
  for(const k of ['stimulus','perception','decision','anticipation','action','consequence','camera','audio','failed_pattern','repair_strategy','rig']){assert.ok(r[k].length>12,`${r.id} ${k}`);checks++;}
  const stages=['stimulus','perception','decision','anticipation','action','consequence','end'];
  assert.deepEqual(stages.map(x=>x in r.phase_frames),[true,true,true,true,true,true,true]);checks++;
  const times=stages.map(x=>r.phase_frames[x]);
  assert.equal(times[0],0);checks++;
  assert.equal(times.at(-1),r.duration_frames);checks++;
  assert.ok(times.every((v,i)=>i===0||v>times[i-1]));checks++;
  assert.ok(r.curves[r.primary_channel]);checks++;
  for(const f of [0,r.phase_frames.action-1,r.phase_frames.action,r.duration_frames-1]){
    const pose=sampleAction(r.id,f,recipes);checks++;
    assert.ok(Number.isFinite(pose.channels[r.primary_channel]));checks++;
    assert.equal(pose.frame,f);checks++;
  }
  let prev=-1;
  for(let f=0;f<r.duration_frames;f++){
    const v=sampleAction(r.id,f,recipes).channels[r.primary_channel];
    assert.ok(v>=prev-1e-8 && v>=-1e-8 && v<=1.00000001);checks++;
    prev=v;
  }
}
assert.equal(sampleCurve([[0,0],[20,1]],0),0);checks++;
assert.equal(sampleCurve([[0,0],[20,1]],20),1);checks++;
assert.throws(()=>sampleAction('ACT-999',0,recipes));checks++;
assert.throws(()=>sampleAction('ACT-001',-1,recipes));checks++;
console.log(`Lesson 05 sampler/data checks PASS: ${checks} assertions; 42 recipes; runtime data sample only, not an AE or motion quality test.`);
