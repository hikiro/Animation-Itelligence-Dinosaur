/** Example: node 08_TOOLS/example_action_recipe.mjs ACT-025 55 */
import {readFileSync} from 'node:fs';
import {sampleAction} from './action_engine.mjs';
const path=new URL('../12_ACTION_INTELLIGENCE/DATA/action_recipes.json', import.meta.url);
const recipes=JSON.parse(readFileSync(path,'utf8'));
const id=process.argv[2] || 'ACT-025';
const frame=Number(process.argv[3] ?? '55');
console.log(JSON.stringify(sampleAction(id,frame,recipes),null,2));
