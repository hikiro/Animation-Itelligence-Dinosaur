# Learning log — chronological, append only

This log records research **performed in a session**, not autonomous, continuous background study. Always distinguish source inspection from runtime validation.

## 2026-11-18 — Original DINO quality inspection (historical audit)

- **ID:** LOG-0001 | **Source:** `07_REFERENCE_V2/DINO_ANIMATION_QUALITY_AUDIT.md`, `07_REFERENCE_V2/MOTION_STORY_LOGIC_QA.md` | **Evidence:** historic original contact sheets and source inspection summarized in archive.
- **Observed:** portal entrance not visibly completed; gait, body reactions, temporal spacing, camera/story action independence were weak.
- **Result:** `LRN-0001`, `LRN-0002`, `CASE-0001`; proposed a causal action-completion test.
- **Status:** observed original issue; subsequent repair NOT verified.

## 2026-11-19 — Film grammar and sound context research (V3 carried forward)

- **ID:** LOG-0002 | **Sources:** S01–S25 in source ledger.
- **Learned:** camera, motion and sound must be chosen for the same story event and viewer knowledge; cut on action, depth, offscreen sound, sound perspective, score priority.
- **Result:** `LRN-0004`; `01_RESEARCH/05_CONTEXT_COUPLING.md`.
- **Status:** sourced practice + project synthesis; not a new render.

## 2026-11-19 — After Effects expression/layer research

- **ID:** LOG-0003 | **Sources:** Adobe expression language, layers/solids/mattes, Puppet, Graph Editor, AE cameras/motion blur, effects/controls, Dan Ebberts bounce references (S26–S44).
- **Learned:** expressions are per-property computed values, not scene-creation scripts; built rigs/mattes/keyframes do primary storytelling; `wiggle`, `ease`, `valueAtTime`, `loopOut`, `posterizeTime`, controls and layer-space conversion each have specific uses/limitations.
- **Result:** `11_AFTER_EFFECTS/` study track, `LRN-0003`, `LRN-0006`, `LRN-0007`.
- **Status:** source-backed concepts; snippets **NOT TESTED IN AE**, no AEP or new MP4.

## 2026-11-19 — User's natural-language-to-code example

- **ID:** LOG-0004 | **Input:** fictional projectile impact should clearly show cause, recoil, travel, camera insert, manga/water aesthetic, contact, character shake and fall.
- **Learned:** don't literalize adjectives: translate into physical action graph, visual emphasis, editorial coverage, sound perspective, implementation layers and observability tests. Distinguish stylized path/time and objective physical motion.
- **Result:** `INT-0001`, `LRN-0005`, `LRN-0009`, new `GOAL-001/004/008`, `CONFLICT-001–007`.
- **Status:** authored translation example; still needs actual test animation.

## Pending experiments

- `EXP-0001`: AE portal cross with front/back mattes and planted foot; inspect inside / straddling / outside.
- `EXP-0002`: AE property comparison for contact-only pose vs contact + shake; silent viewer action-identification test.
- `EXP-0003`: Separate actual projectile path and camera path; compare geographical comprehension.
- `EXP-0004`: Verify all expression snippets in a real AE version with screenshot and render evidence.
- `EXP-0005`: Search quality testing on synonyms, IDs and titles across new chats.
