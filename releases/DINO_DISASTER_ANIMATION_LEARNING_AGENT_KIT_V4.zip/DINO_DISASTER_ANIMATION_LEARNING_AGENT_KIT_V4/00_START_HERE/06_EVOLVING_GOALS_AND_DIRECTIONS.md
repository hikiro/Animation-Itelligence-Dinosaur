# Living goals and directions — user-authorized design contract

**Updated:** 2026-11-19. **Status:** ongoing learning; no claim of autonomous background research.

## Goals and priority

| ID | Priority | Goal | Verification | Status |
|---|---|---|---|---|
| GOAL-001 | P0 | Translate everyday natural-language creative direction into story-causal, executable animation instructions | Direction contract contains meaning, beats, cameras, rigs, layers, audio, expressions/effects, QA tests | Active |
| GOAL-002 | P0 | Preserve detailed evolving lessons across conversations as portable Markdown | Searchable lessons, append-only log, source evidence, uncertainty, stable IDs, local search tests | V4 documentation created |
| GOAL-003 | P0 | Every character movement motivated, legible and physically coordinated | Stimulus → noticing → decision → anticipation → action → consequence and recovery | Principle; unverified on new render |
| GOAL-004 | P0 | Learn Adobe After Effects layers, solids, mattes, puppet/rigs, keyframes, graph editor, expressions, cameras, sound context | Technical guide, expression map, runnable-in-AE examples, provenance; verify in actual AE before claiming tested | Research documented, AE runtime untested |
| GOAL-005 | P0 | Camera, motion and sound jointly communicate the exact story event and emotional context | Context triplet and sound/event cues for each major beat | Documentation created |
| GOAL-006 | P0 | Detect hallucinations, unsupported claims, mis-sequenced actions, and missing outputs | Evidence labels, anti-hallucination stop rule, recovery card and defects | Operating contract active |
| GOAL-007 | P1 | Build professional 9-second portal crossing before full 80-second film | Inspectable 270-frame rendered scene, true portal passage, foot contacts, audio evidence | Not rendered; acceptance unchanged |
| GOAL-008 | P1 | Distinguish expressive stylization from grounded physics, and flag ambiguous/conflicting direction | Alternatives + decision log + no silent style switch | Ongoing |
| GOAL-009 | P2 | Generalize reusable animations beyond dinosaur project | Neutral templates and context translator applicable to any non-graphic story | Architecture created |

## Most recent user direction (INT-0001)

> “If I say the bullet impact should be understood, infer connected recoil, traveled projectile, cinematic tracking/speed, manga-like art emphasis, actual hit, physical reaction, and slow fall.”

Treat this as a **translation case study**, not authorization to add a shooting event to DINO//DISASTER. This shows how abstract adjectives or verbs imply a causal action graph.

## Editing protocol

- On every new task, compare user language with active goals and locked project rules.
- Distinguish `APPROVED`, `PROPOSED`, `RESEARCHED`, `RENDERED_VERIFIED`, `NOT_TESTED`.
- When direction changes a locked narrative event, document `CONFLICT-####` before modifying story.
- Update this file plus `09_HANDOFF/DECISION_LOG.md`, `10_KNOWLEDGE/LEARNING_LOG.md`, relevant lessons, and a searchable index.
- If no actual tool research or render takes place, do not mark it done. No claim of unattended or future background work.

## Working human-language vocabulary

- “More alive” → clear intention, anticipatory posture, delayed overlap, expressive gaze and purposeful recovery.
- “More punchy” → shorter anticipation/stronger contrast, decisive contact accent, controlled audiovisual peak; not random screen shake.
- “Cinematic” → viewer-aligned framing, lens/perspective choices, motivated camera path, rhythmic editing, selective sound perspective.
- “Impact reads” → source, trajectory, exact contact, force response, causal sound, aftermath and a readability check.
- “Smooth” → controlled spacing/velocity continuity as intended; not smoothing deliberate impact or hold poses.
- “Realistic” → believable causality, inertia, contact, plausible dynamics; do not over-stylize without noting change.
- “Anime/manga” → intentional graphic style, impact frames, speed lines, holds, compositional compression, dramatic contrast; avoid assuming every technique applies.
