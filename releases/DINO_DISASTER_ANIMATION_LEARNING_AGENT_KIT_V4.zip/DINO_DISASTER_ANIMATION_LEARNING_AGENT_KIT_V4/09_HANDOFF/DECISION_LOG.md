# Decision log — intent and history

| Date | Decision | Why | Status |
|---|---|---|---|
| 2026-11-18 | Original four 5s tests are insufficient quality | Sliding/incorrect portal exit, gait and logical/action failures | Historical critique; see `07_REFERENCE_V2/` |
| 2026-11-18 | Expand to ~80s story of egg rescue, protective mother and portal return | Meaningful cause/effect, emotional reversal and cliffhanger | Story adopted in current docs |
| 2026-11-19 | Use handmade 2.5D Japanese-inspired paper cut with articulated rigs | Distinct tactile look, manageable rigged performance | Creative lock |
| 2026-11-19 | Require 9s benchmark first | Avoid repeated critical crossing failure and prevent wasted full render | Explicitly accepted by user |
| 2026-11-19 | Integrate contextual camera/motion/sound | Story lens, sound POV, action intention must be coherent | V3 principle |
| 2026-11-19 | Package in modular prompts with state machine and evidence-gated QC | Prevent lost-chat drift, hallucinated render claims and giant vague prompts | V3 structure |
| 2026-11-19 | V2 copies archive-only, not current source of truth | Prevent stale text overriding approved V3 process | Governance |

Add rows for any future creative or technical choice affecting timeline, physics, camera axis, character goal, portal mechanics, sound premise or QA definition of done. Do not silently overwrite past decisions.

## V4 direction acceptance (2026-11-19)

- `DEC-V4-01` **ACTIVE**: Build a human-language-to-code/animation translation library. Project-specific examples are not automatically inserted into the locked Dino story.
- `DEC-V4-02` **ACTIVE**: Research Adobe After Effects expressions/layers/solids and explain mechanics in ordinary words with context, limits and QA.
- `DEC-V4-03` **ACTIVE**: Keep append-only evidence-linked Markdown learning log, searchable index and tracked conflicts. Learning happens when an active session does actual research/QA, never autonomously in background.
- `DEC-V4-04` **ACTIVE**: A visually cinematic effect does not excuse missing cause/contact/reaction. Resolve conflicts using user intent and documented style choice.
