# Conflicts, trade-offs, and decisions

Keep a row even after resolved. When uncertain, present the options rather than silently choosing.

| ID | Statement A | Statement B | Current resolution | Evidence / QA |
|---|---|---|---|---|
| CONFLICT-001 | “Bullet follows a curved trajectory” | Grounded, fast projectile motion usually reads near-straight over short distances | Distinguish **actual path** from camera motion, speed ramp, stylized trail. Default literal physical path = direct; stylized curve only when explicit stylization is intended | Check continuous path and intended realism |
| CONFLICT-002 | “Hit = intense shake” | Whole-body acting must maintain understandable balance and grounded contact | Shake accent is subordinate to contact/pose and force; avoid whole-comp random jitter. Use decay only after actual impact | Inspect pre-hit, contact and recovery frames |
| CONFLICT-003 | “Camera zooms to projectile then out to victim” | Editing geography and travel time may make the shot unreadable | Establish start and target locations, cut to planned insert/tracking if necessary, match screen direction back to target. Do not assume literal single-camera zoom is always best | Silent-read spatial test |
| CONFLICT-004 | “Character falls slowly” | Physical reaction should show initial force and gravity | Separate fast impact/compression, destabilization, **stylized** temporal dilation, then continued fall and landing; avoid weightless float | Whole-body path and timing review |
| CONFLICT-005 | “Expressions do the animation” | Expressions compute property values; not story logic or a rig | Choose hand-authored key poses, links, physical constraints, then use expressions for secondary procedural behavior | Rig + contact tests |
| CONFLICT-006 | “Use After Effects resources” | V3 Dino production renderer was previously tool-agnostic; exact AE app not available in this environment | AE becomes a **reference implementation learning track**, not a claim the DINO film already uses AE or that expression samples ran in AE | Toolchain state; label snippets not AE-tested |
| CONFLICT-007 | High-energy manga flashes and impact | Platform photosensitivity / legibility | Prefer a controlled, non-strobing contrast accent rather than repetitive flashing. QA for readability and photosensitivity risk | Review full render at target speed |

**Decision owner:** Explicit user direction outranks this project file. All new conflicts require a new ID, date, affected scene, alternatives, chosen approach, and re-test. The last `status` and actual render remain the source of truth.
